# You should write code here to estimate preliminary models using your
# pilot data
